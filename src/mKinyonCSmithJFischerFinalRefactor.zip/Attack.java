
public interface Attack {
	public void regularAttack(GameCharacter opponent);
	public void specialAttack(GameCharacter opponent);
}
